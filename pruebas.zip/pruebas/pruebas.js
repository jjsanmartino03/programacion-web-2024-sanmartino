let nombre = 'Julián'
console.log(nombre)
console.log(typeof (nombre));

let numero = 10
console.log(numero)
console.log(typeof (numero));

let arr = [25, 'hola', 21, true]
console.log(arr);
console.log(typeof (arr));
console.log(arr[2]);


let persona  = {
    nombre: 'Juan',
    edad: 30,
    "Mi pais": "Argentina",
    Saludar: function () {
        console.log('Hola mundo, ¿cómo estás?');
    }
}
console.log(persona);
console.log(persona.nombre);
console.log(persona["Mi pais"]);